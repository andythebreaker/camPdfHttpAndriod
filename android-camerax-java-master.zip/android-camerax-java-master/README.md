# android-camerax-java
A simple demo tutorial of the implementation of Android CameraX with Java
